﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Task1BackEnd
{
    [Route("api/[controller]")]
    public class BackEndApiController : Controller
    {
        // GET: api/<controller>
        [HttpGet]
        public JObject Get(string CityName,string CountryCode)
        {
            using (WebClient httpClient = new WebClient())
            {



                var jsonData = httpClient.DownloadString("http://api.openweathermap.org/data/2.5/forecast?q=" + CityName + "," + CountryCode + "&mode=json&appid=fcadd28326c90c3262054e0e6ca599cd");
                JObject jObject = JObject.Parse(jsonData);

                return jObject;
            }
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
