﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Task1BackEnd.Pages
{
    public class IndexModel : PageModel
    {

        public RootObject root = new RootObject();
        public List<List> allData = new List<List>();
        public string CityName { get; set; }
        public string CountryCode { get; set; }
      
        [HttpGet]
        public void OnGet()
        {
            RootObject root = new RootObject();

            List list = new List();
            using (WebClient httpClient = new WebClient())
            {

                CityName = string.IsNullOrEmpty(CityName) ? "Munich" : CityName;
                CountryCode = string.IsNullOrEmpty(CountryCode) ? "de" : CountryCode;
                var jsonData = httpClient.DownloadString("http://api.openweathermap.org/data/2.5/forecast?q=" + CityName + "," + CountryCode + "&mode=json&appid=fcadd28326c90c3262054e0e6ca599cd");
                JObject jObject = JObject.Parse(jsonData);
                list.main = new Main();
                for (int i = 0; i < 35; i++)
                {
                    list = new List();
                    list.main = new Main();
                    list.dt = (int)jObject.SelectToken("list[" + i + "].dt");
                    list.dt_txt = (string)jObject.SelectToken("list[" + i + "].dt_txt");
                    list.main.temp = (double)jObject.SelectToken("list[" + i + "].main.temp");
                    list.main.temp_min = (double)jObject.SelectToken("list[" + i + "].main.temp_min");
                    list.main.temp_max = (double)jObject.SelectToken("list[" + i + "].main.temp_max");
                    list.main.pressure = (double)jObject.SelectToken("list[" + i + "].main.pressure");
                    list.main.humidity = (int)jObject.SelectToken("list[" + i + "].main.humidity");
                    list.main.sea_level = (int)jObject.SelectToken("list[" + i + "].main.sea_level");
                    list.main.grnd_level = (int)jObject.SelectToken("list[" + i + "].main.grnd_level");
                    allData.Add(list);
                }




            }
        }


        public void OnPost()
        {
            CityName= Request.Form["CityName"];
            CountryCode= Request.Form["CountryCode"];
            OnGet();
        }
         


    
    }
}