﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherController : ControllerBase
    {
        // GET: api/Weather
        [HttpGet]
        public JObject Get(string CityName,string CountryCode)
        {
            using (WebClient httpClient = new WebClient())
            {



                var jsonData = httpClient.DownloadString("http://api.openweathermap.org/data/2.5/forecast?q=" + CityName + "," + CountryCode + "&mode=json&appid=fcadd28326c90c3262054e0e6ca599cd");
                JObject jObject = JObject.Parse(jsonData);

                return jObject;
            }
        }

        // GET: api/Weather/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Weather
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Weather/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
